package com.adobe.aem.guides.marlabs.core.workflow;

import org.osgi.service.component.annotations.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.granite.workflow.WorkflowException;
import com.adobe.granite.workflow.WorkflowSession;
import com.adobe.granite.workflow.exec.ParticipantStepChooser;
import com.adobe.granite.workflow.exec.WorkItem;
import com.adobe.granite.workflow.metadata.MetaDataMap;

@Component(service = ParticipantStepChooser.class, immediate = true, property = {
		ParticipantStepChooser.SERVICE_PROPERTY_LABEL + "=Marlabs Editor Participant Chooser" })
public class MarlabsEditorParticipantChooser implements ParticipantStepChooser {

	private final Logger log = LoggerFactory.getLogger(getClass());

	@Override
	public String getParticipant(WorkItem workItem, WorkflowSession workflowSession, MetaDataMap metadataMap)
			throws WorkflowException {

		String partcipant = null;
		String workflowTitle = workItem.getWorkflowData().getMetaDataMap().get("workflowTitle").toString();
		log.debug("workflowTitle : {}", workflowTitle);
		partcipant = workItem.getWorkflow().getInitiator();
		log.debug("partcipant : {}", partcipant);
		return partcipant;
	}
}
