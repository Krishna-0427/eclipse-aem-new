package com.adobe.aem.guides.marlabs.core.services;

import javax.jcr.LoginException;
import javax.jcr.Session;

import org.apache.sling.api.resource.ResourceResolver;

public interface GlobalConfigService {

	ResourceResolver getResourceResolver() throws LoginException;

	Session getAdminSession();

}
