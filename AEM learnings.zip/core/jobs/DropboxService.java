package com.adobe.aem.guides.marlabs.core.jobs;

import java.util.HashMap;
import java.util.Map;

import javax.jcr.Session;

import org.apache.jackrabbit.commons.JcrUtils;
import org.apache.sling.api.SlingConstants;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.event.jobs.JobManager;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.osgi.service.event.Event;
import org.osgi.service.event.EventConstants;
import org.osgi.service.event.EventHandler;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.marlabs.core.services.GlobalConfigService;

/**
 * The <code>DropBoxService</code> is listening content added to /tmp/dropbox by
 * using OSGI events
 *
 */

@Component(service = EventHandler.class, immediate = true, property = {
		Constants.SERVICE_DESCRIPTION + "=Dropbox Service",
		EventConstants.EVENT_TOPIC + "=org/apache/sling/api/resource/Resource/*" })
public class DropboxService implements EventHandler {

	@Reference
	private JobManager jobManager;

	@Reference
	private GlobalConfigService configService;

	private static final Logger log = LoggerFactory.getLogger(DropboxService.class);

	/** The job topic for dropbox job events. */
	public static final String JOB_TOPIC = "com/sling/eventing/dropbox/job";

	private final static String SLING_NODE_TYPE = "sling:Folder";
	private final static String ROOT_PATH = "/tmp/dropbox";
	private final static String IMAGES_PATH = "/tmp/dropbox/images";
	private final static String MUSIC_PATH = "/tmp/dropbox/music";
	private final static String MOVIES_PATH = "/tmp/dropbox/movies";
	private final static String OTHER_PATH = "/tmp/dropbox/other";

	@Override
	public void handleEvent(final Event event) {
		ResourceResolver adminResolver = null;
		Session adminSession = null;
		try {
			adminResolver = configService.getResourceResolver();
			// get the resource event information
			final String propPath = (String) event.getProperty(SlingConstants.PROPERTY_PATH);
			final String propResType = (String) event.getProperty(SlingConstants.PROPERTY_RESOURCE_TYPE);

			// a job is started if a file is added to /tmp/dropbox
			if (propPath.startsWith("/tmp/dropbox") && "nt:file".equals(propResType)) {

				adminSession = adminResolver.adaptTo(Session.class);

				JcrUtils.getOrCreateByPath(ROOT_PATH, null, SLING_NODE_TYPE, adminSession, true);
				JcrUtils.getOrCreateByPath(IMAGES_PATH, null, SLING_NODE_TYPE, adminSession, true);
				JcrUtils.getOrCreateByPath(MUSIC_PATH, null, SLING_NODE_TYPE, adminSession, true);
				JcrUtils.getOrCreateByPath(MOVIES_PATH, null, SLING_NODE_TYPE, adminSession, true);
				JcrUtils.getOrCreateByPath(OTHER_PATH, null, SLING_NODE_TYPE, adminSession, true);

				// create payload
				final Map<String, Object> payload = new HashMap<String, Object>();
				payload.put("resourcePath", propPath);
				// start job
				this.jobManager.addJob(JOB_TOPIC, payload);	
				log.info("the dropbox job has been started for: {}", propPath);
			}
		} catch (final Exception e) {
			log.error("Exception: " + e, e);
		} finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
			if (adminSession != null && adminSession.isLive()) {
				adminSession.logout();
			}
		}
	}

}
