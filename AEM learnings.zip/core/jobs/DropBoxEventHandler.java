package com.adobe.aem.guides.marlabs.core.jobs;

import javax.jcr.Session;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.event.jobs.Job;
import org.apache.sling.event.jobs.consumer.JobConsumer;
import org.osgi.framework.Constants;
import org.osgi.service.component.annotations.Component;
import org.osgi.service.component.annotations.Reference;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.adobe.aem.guides.marlabs.core.services.GlobalConfigService;

/**
 * The <code>DropBoxEventHandler</code> moves files posted to /tmp/dropbox to
 * the appropriate locations: images (MIME type: image/png) to /dropbox/images/
 * music (MIME type: audio/mpeg) to /dropbox/music/ movies (MIME type:
 * video/x-msvideo) to /dropbox/movies/ otherwise to /dropbox/other/
 *
 */

@Component(service = JobConsumer.class, immediate = true, property = {
		Constants.SERVICE_DESCRIPTION + "=DropBox Event Handler",
		JobConsumer.PROPERTY_TOPICS + "=com/sling/eventing/dropbox/job" })
public class DropBoxEventHandler implements JobConsumer {

	/** Default log. */
	protected final Logger logger = LoggerFactory.getLogger(this.getClass());

	@Reference
	private GlobalConfigService configService;

	private final static String IMAGES_PATH = "/tmp/dropbox/images/";
	private final static String MUSIC_PATH = "/tmp/dropbox/music/";
	private final static String MOVIES_PATH = "/tmp/dropbox/movies/";
	private final static String OTHER_PATH = "/tmp/dropbox/other/";

	@Override
	public JobResult process(final Job job) {
		ResourceResolver adminResolver = null;
		Session adminSession = null;
		try {
			adminResolver = configService.getResourceResolver();

			final String resourcePath = (String) job.getProperty("resourcePath");
			final String resourceName = resourcePath.substring(resourcePath.lastIndexOf("/") + 1);

			final Resource res = adminResolver.getResource(resourcePath);
			if (res.isResourceType("nt:file")) {
				final String mimeType = res.getResourceMetadata().getContentType();
				String destDir;
				if (mimeType.contains("image")) {
					destDir = IMAGES_PATH;
				} else if (mimeType.contains("audio")) {
					destDir = MUSIC_PATH;
				} else if (mimeType.contains("video")) {
					destDir = MOVIES_PATH;
				} else {
					destDir = OTHER_PATH;
				}
				adminSession = adminResolver.adaptTo(Session.class);
				if (!adminSession.itemExists(destDir + resourceName)) {
					adminSession.move(resourcePath, destDir + resourceName);
					adminSession.save();
				}
				logger.info("The file {} has been moved to {}", resourceName, destDir);
			}
			return JobResult.OK;
		} catch (final Exception e) {
			logger.error("Exception: " + e, e);
			return JobResult.FAILED;
		} finally {
			if (adminResolver != null) {
				adminResolver.close();
			}
			if (adminSession != null && adminSession.isLive()) {
				adminSession.logout();
			}
		}
	}

}
