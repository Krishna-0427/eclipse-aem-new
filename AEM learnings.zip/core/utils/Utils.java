package com.adobe.aem.guides.marlabs.core.utils;

public class Utils {
	public static void main(String[] args) {
		String str = "Prerajulisation"; // Step 1
		System.out.println("substring : " + str.substring(10));   // Step 2
	}
}
