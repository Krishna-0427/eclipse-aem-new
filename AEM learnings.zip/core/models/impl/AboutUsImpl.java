/*
 * package com.adobe.aem.guides.marlabs.core.models.impl;
 * 
 * import java.util.List;
 * 
 * import org.apache.sling.api.SlingHttpServletRequest; import
 * org.apache.sling.models.annotations.Model; import
 * org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
 * 
 * import com.adobe.aem.guides.marlabs.core.models.AboutUs;
 * 
 * @Model(adaptables = { SlingHttpServletRequest.class }, adapters = {
 * AboutUs.class }, resourceType = { AboutUsImpl.RESOURCE_TYPE })
 * 
 * public class AboutUsImpl implements AboutUs{ protected static final String
 * RESOURCE_TYPE = "aem-learning/components/marlabs-commerce-about-us";
 * 
 * 
 * @ValueMapValue private List KPIParameters;
 * 
 * 
 * @override public list<string> getkpiparameters() { for(object str :
 * kpiparameters) {
 * 
 * } return list; }
 * 
 * @Override public boolean isEmpty() {
 * 
 * return false; }
 * 
 * 
 * 
 * 
 * }
 */