package com.adobe.aem.guides.marlabs.core.models;


import java.util.*;
import javax.annotation.PostConstruct;
import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import com.day.cq.wcm.api.Page;

@Model(adaptables = { SlingHttpServletRequest.class,
		Resource.class }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class SiteMapWithIncrementFeature {
private List<Page> items = new ArrayList<Page>();
	
    @ValueMapValue
    private String pagePath;
    
    @ValueMapValue
    private int childDepth;
    
    @ScriptVariable
	protected ValueMap properties;
    
    @SlingObject
    private ResourceResolver resourceResolver;
    
    private static final String PN_CHILD_DEPTH = "childDepth";
    
    private static final int CHILD_DEPTH_DEFAULT = 1;
    
    private String rootPageTitle;
    
    private String rootPageLink;
    
    private static final String PN_ROOT_CHECKBOX = "myBooleanCheckbox";
    
    private static final Boolean CHECKBOX_DEFAULT = false;
    
    private Boolean checkRoot;
    
    @PostConstruct
	protected void init() {
		if (StringUtils.isNotBlank(pagePath)) {
			Resource pageResource = resourceResolver.getResource(pagePath);
			Page currentPage = pageResource != null ? pageResource.adaptTo(Page.class) : null;
			checkRoot = properties.get(PN_ROOT_CHECKBOX, CHECKBOX_DEFAULT);
			if(checkRoot) {
				rootPageTitle = currentPage.getTitle(); 
				rootPageLink = currentPage.getPath();
			}
			if (currentPage != null) {
			    collectChildren(currentPage.getDepth(), currentPage);
			}
		}
	}
    
    private List<Page> collectChildren(int startLevel, Page parent) {
    	int childDepth = properties.get(PN_CHILD_DEPTH, CHILD_DEPTH_DEFAULT);
    	  Iterator<Page> childIterator = parent.listChildren();
    	  while (childIterator.hasNext()) {
    	    Page child = childIterator.next();
    	    items.add(child);
    	    if (child.getDepth() - startLevel < childDepth) {
    	      collectChildren(startLevel, child);
    	    }
    	  }
		return items;
    	}
    
	public List<Page> getItems() {
        return items;
    }

	public String getRootPageLink() {
		return rootPageLink;
	}
	
	public String getRootPageTitle() {
		return rootPageTitle;
	}


}


