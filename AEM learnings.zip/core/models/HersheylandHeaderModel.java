package com.adobe.aem.guides.marlabs.core.models;
 
import javax.inject.Inject;
 
import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL, resourceType = {
		HersheylandHeaderModel.RESOURCE_TYPE })

public class HersheylandHeaderModel {
 
    private final Logger log = LoggerFactory.getLogger(getClass());
 
    protected static final String RESOURCE_TYPE = "aem-learning/components/hersheyland-header";
 
    @Inject
    @Optional
    private Resource headerDetails;
 
    public Resource getHeaderDetails() {
        log.debug(" headerDetails Resource : {}", headerDetails);
        return headerDetails;
    }
}








