package com.adobe.aem.guides.marlabs.core.models;
 

 
import javax.inject.Inject;

import org.apache.sling.api.resource.Resource;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
 
@Model(adaptables = Resource.class, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL, resourceType = {
		HersheylandIngredientsAndDirectionsModel.RESOURCE_TYPE })

public class HersheylandIngredientsAndDirectionsModel {
 
    private final Logger log = LoggerFactory.getLogger(getClass());
 
    protected static final String RESOURCE_TYPE = "aem-learning/components/hersheyland-ingre-and-dir";
 
    @Inject
    @Optional
    private Resource requirements;
 
    public Resource getRequirements() {
        log.debug("RequirementsLoop Resource : {}", requirements);
        return requirements;
    }
    
    
    @Inject
    @Optional
    private Resource IngredientsList;
 
    public Resource getIngredientsList() {
        log.debug("IngredientsList Resource : {}", IngredientsList);
        return IngredientsList;
    }

    
    @Inject
    @Optional
    private Resource directionsList;
 
    public Resource getDirectionsList() {
        log.debug("directionsList Resource : {}", directionsList);
        return directionsList;
    }
    
    @Inject
    @Optional
    private Resource procedureList;
 
    public Resource getProcedureList() {
        log.debug("procedureList Resource : {}", procedureList);
        return procedureList;
    }
}

