package com.adobe.aem.guides.marlabs.core.models;

import java.util.List;

public interface AboutUs {
	
	  List<String> getKpiParameters();

	 
	    boolean isEmpty();

}
