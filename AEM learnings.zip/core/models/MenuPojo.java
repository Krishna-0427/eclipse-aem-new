package com.adobe.aem.guides.marlabs.core.models;
import java.util.*;
public class MenuPojo {

    private String pageTitle;
    private String pageLink;
    private List<MenuPojo> childPages;
    private String pageRootName;
    private String description;
    
    
    public String getPageTitle() {
        return pageTitle;
    }
    public String getDescription() {
        return description;
    }
    

    public void setPageTitle(String pageTitle) {
        this.pageTitle = pageTitle;
    }
    public void setDescription(String description) {
        this.description = description;
    }

    public String getPageLink() {
        return pageLink;
    }

    public void setPageLink(String pageLink) {
        this.pageLink = pageLink;
    }

    public List<MenuPojo> getChildPages() {
        return childPages;
    }

    public void setChildPages(List<MenuPojo> childPages) {
        this.childPages = childPages;
    }

	public void setPageRootName(String pageRootName) {
		this.pageRootName = pageRootName;
	}
	 public String setPageRootName() {
	        return pageRootName;
	    }
}