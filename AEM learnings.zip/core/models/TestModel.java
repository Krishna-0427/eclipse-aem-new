package com.adobe.aem.guides.marlabs.core.models;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.inject.Inject;

import org.apache.commons.lang3.StringUtils;
import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.api.resource.Resource;
import org.apache.sling.api.resource.ResourceResolver;
import org.apache.sling.api.resource.ValueMap;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.Optional;
import org.apache.sling.models.annotations.injectorspecific.ScriptVariable;
import org.apache.sling.models.annotations.injectorspecific.SlingObject;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.day.cq.wcm.api.Page;





  
 @Model(adaptables = {SlingHttpServletRequest.class, Resource.class}, 
		 defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)
 
 public class TestModel  {
  
     private final Logger log = LoggerFactory.getLogger(TestModel.class);
  
     protected static final String RESOURCE_TYPE = "aem-learning/components/SiteMapFinal";
  
     
   
     
     
     @ValueMapValue
 	private String TitleNameHere;
     
     public String getTitleNameHere()
     {
    	 
    	 
    	 return TitleNameHere;
     }
     
     @ValueMapValue
  	private String PageRooLink;
      
      public String getPageRooLink()
      {
     	 
     	 
     	 return PageRooLink;
      }
     
     
     @ScriptVariable
     private Page currentPage;
     
     
     @ValueMapValue
     private String pagePath; // Here you need to map with the dialog name

     @SlingObject
     private ResourceResolver resourceResolver;

     private List<MenuPojo> menuList = new ArrayList<>();

     @PostConstruct
     protected void init() {
         log.info("***** :: init :: Start :: ******");
         if (StringUtils.isNotBlank(pagePath)) {
             Resource pageResource = resourceResolver.getResource(pagePath);
             
             Page currentPage = pageResource != null ? pageResource.adaptTo(Page.class) : null;
             menuList = currentPage != null ? getFirstLevelItems(currentPage, menuList) : null;
             TitleNameHere =currentPage.getTitle();
             PageRooLink=currentPage.getPath();
       
         }
         log.info("***** :: init :: End :: *****");
     }
       
     private List<MenuPojo> getFirstLevelItems(Page rootPage, List<MenuPojo> menuList) {
         Iterator<Page> firstLevelChild = rootPage.listChildren();
         while (firstLevelChild.hasNext()) {
             Page firstLevelPage = firstLevelChild.next();
             if (!firstLevelPage.isHideInNav()) {
                 getMenuList(menuList, firstLevelPage);
             }
         }
         return menuList;
     }
     
     private void getMenuList(List<MenuPojo> menuList, Page firstLevelPage) {
         MenuPojo navObj = new MenuPojo();
         
         ValueMap firstLevelPageProperties = firstLevelPage.getProperties();
         String pathLink = firstLevelPage.getPath();
         navObj.setPageLink(pathLink);
         navObj.setPageTitle(firstLevelPage.getTitle());
         if (firstLevelPage.listChildren().hasNext()) {
             List<MenuPojo> secondLevelItemList = new ArrayList<>();
             secondLevelItemList = getFirstLevelItems(firstLevelPage, secondLevelItemList);
             navObj.setChildPages(secondLevelItemList);
             
            
         }
         menuList.add(navObj);
         
     }

     public List<MenuPojo> getMenuList() {
         return menuList;
     }
     
     

	    @Inject
	    @Optional
	    private Resource SiteMapParameters;
	 
	    public Resource getSiteMapParameters() {
	        log.debug("ImageParameters Resource : {}", SiteMapParameters);
	        return SiteMapParameters;
	    }
 }


 

