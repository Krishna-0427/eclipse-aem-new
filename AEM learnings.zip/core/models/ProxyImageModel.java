package com.adobe.aem.guides.marlabs.core.models;








import javax.annotation.PostConstruct;

import org.apache.sling.api.SlingHttpServletRequest;
import org.apache.sling.models.annotations.DefaultInjectionStrategy;
import org.apache.sling.models.annotations.Model;
import org.apache.sling.models.annotations.injectorspecific.OSGiService;
import org.apache.sling.models.annotations.injectorspecific.Self;
import org.apache.sling.models.annotations.injectorspecific.ValueMapValue;
import org.apache.sling.models.factory.ModelFactory;

import com.adobe.cq.wcm.core.components.models.Image;

@Model(adaptables = { SlingHttpServletRequest.class }, adapters = { Byline.class }, resourceType = {
		BylineImpl.RESOURCE_TYPE }, defaultInjectionStrategy = DefaultInjectionStrategy.OPTIONAL)

public class ProxyImageModel  {
	protected static final String RESOURCE_TYPE = "aem-learning/components/proxy-Image";

	

	
	  
	 
	 
	 @ValueMapValue
	private String fileName;
	 
	 public String getPathname()
	 {
		 return fileName;
	 }
	 
	 
	 
		/*
		 * @Self private Image image;
		 */
	  
	  @Self
	  private SlingHttpServletRequest request;
	  @OSGiService
	    private ModelFactory modelFactory;
	  
	  private Image image;
	    @PostConstruct
	    private void init() {
	        image = modelFactory.getModelFromWrappedRequest(request,
	                                                        request.getResource(),
	                                                        Image.class);
	    }

	  
	  private Image getImage() {
		    return  image;
		}
}

